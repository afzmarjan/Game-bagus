function createMatrixRain() {
	const matrixContainer = document.getElementById('matrixRain');
	const chars = '01アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン';

	for (let i = 0; i < 50; i++) {
		const column = document.createElement('div');
		column.className = 'matrix-column';
		column.style.left = Math.random() * 100 + '%';
		column.style.animationDuration = (Math.random() * 3 + 2) + 's';
		column.style.animationDelay = Math.random() * 2 + 's';

		let columnText = '';
		for (let j = 0; j < 20; j++) {
			columnText += chars.charAt(Math.floor(Math.random() * chars.length)) + '<br>';
		}
		column.innerHTML = columnText;

		matrixContainer.appendChild(column);
	}
}

document.getElementById('togglePassword').addEventListener('click', function() {
	const passwordInput = document.getElementById('password');
	const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
	passwordInput.setAttribute('type', type);
	this.classList.toggle('fa-eye');
	this.classList.toggle('fa-eye-slash');
});

document.getElementById('loginForm').addEventListener('submit', function(e) {
	e.preventDefault();

	const username = document.getElementById('username').value;
	const password = document.getElementById('password').value;
	const loadingSpinner = document.getElementById('loadingSpinner');
	const btnText = document.getElementById('btnText');
	const successMessage = document.getElementById('successMessage');
	const errorMessage = document.getElementById('errorMessage');
	const loginContainer = document.querySelector('.login-container');

	successMessage.style.display = 'none';
	errorMessage.style.display = 'none';

	loadingSpinner.style.display = 'inline-block';
	btnText.textContent = 'Authenticating...';

	loginContainer.classList.add('glitch');

	setTimeout(() => {
		loadingSpinner.style.display = 'none';
		loginContainer.classList.remove('glitch');

		if (username && password.length >= 4) {
			btnText.textContent = 'Access Granted';
			successMessage.style.display = 'block';

			loginContainer.style.borderColor = '#00ff88';

			setTimeout(() => {
				console.log('Login successful!');
			}, 2000);
		} else {
			btnText.textContent = 'Sign In';
			errorMessage.style.display = 'block';

			loginContainer.style.borderColor = '#ff0080';
			setTimeout(() => {
				loginContainer.style.borderColor = '';
			}, 2000);
		}
	}, 2500);
});

document.querySelectorAll('input').forEach(input => {
	input.addEventListener('focus', function() {
		this.parentElement.style.transform = 'scale(1.02)';
	});

	input.addEventListener('blur', function() {
		this.parentElement.style.transform = 'scale(1)';
	});
});

document.addEventListener('DOMContentLoaded', function() {
	createMatrixRain();

	const container = document.querySelector('.login-container');
	const header = document.querySelector('.header');

	container.style.opacity = '0';
	container.style.transform = 'translateY(30px)';
	header.style.opacity = '0';
	header.style.transform = 'translateY(-30px)';

	setTimeout(() => {
		container.style.transition = 'all 0.8s ease';
		header.style.transition = 'all 0.8s ease';
		container.style.opacity = '1';
		container.style.transform = 'translateY(0)';
		header.style.opacity = '1';
		header.style.transform = 'translateY(0)';
	}, 200);
});

let isTyping = false;
document.getElementById('username').addEventListener('focus', function() {
	if (!isTyping && this.value === '') {
		isTyping = true;
		const text = 'root';
		let i = 0;
		const typeInterval = setInterval(() => {
			if (i < text.length) {
				this.value += text.charAt(i);
				i++;
			} else {
				clearInterval(typeInterval);
				isTyping = false;
			}
		}, 100);
	}
});